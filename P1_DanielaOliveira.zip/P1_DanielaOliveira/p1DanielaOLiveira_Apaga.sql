-- --------  << P1 >>  ----------
--
--                    SCRIPT DE REMOÇÃO (DDL)
--
-- Data Criacao ...........: 23/09/2021
-- Autor(es) ..............: Daniela SOares de OLiveira
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: P1
--
-- Ultimas Alteracoes
--   23/09/2021 => Criacao do script
--
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--
-- ---------------------------------------------------------

use P1;

DROP TABLE possui;

DROP TABLE supervisionar;

DROP TABLE PLANTONISTA;

DROP TABLE HABILIDADE;

DROP TABLE PLANTAO;
