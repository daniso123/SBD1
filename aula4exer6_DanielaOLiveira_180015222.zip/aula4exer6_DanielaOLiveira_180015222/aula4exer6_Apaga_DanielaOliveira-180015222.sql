-- --------------------     << Detran >>     -----------------------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 08/09/2021
-- Autor(es) ..............: Daniela SOares de OLiveira
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: aula4exer6
--
--   => Criação do script de apagar
--
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- -----------------------------------------------------------------

use aula4exer6;

DROP TABLE INFRACAO;
DROP TABLE VEICULO;
DROP TABLE telefone;
DROP TABLE PROPRIETARIO;
DROP TABLE CATEGORIA;
DROP TABLE AGENTE;
DROP TABLE MODELO;
DROP TABLE LOCAL;
DROP TABLE TIPO_INFRACAO;